#ifndef _STACK_H_
#define _STACK_H_

#include <iostream>

using namespace std;

const int MAX = 100;

class Stack{

public:
	Stack();
	~Stack();
	void init_stack();
	int push(int t);
	int pop();
	int get_stack_top(void);
	int is_stack_empty(void);

protected:
	int Arr[MAX];
	int stack_top;
};

Stack::Stack()
{

}

Stack::~Stack(){

}

void Stack::init_stack()
{
	stack_top = -1;
}

int Stack::push(int t)
{
	if (stack_top >= MAX - 1)
	{
		cout << "\nStack overflow !!!";
	}
	Arr[++stack_top] = t;
	return t;
}

int Stack::pop()
{
	if (stack_top < 0)
	{
		cout << "Stack underflow !!!";
	}
	return Arr[stack_top--];
}

int Stack::get_stack_top(void)
{
	return (stack_top < 0) ? -1 : Arr[stack_top];
}

int Stack::is_stack_empty(void)
{
	return (stack_top < 0);
}

#endif