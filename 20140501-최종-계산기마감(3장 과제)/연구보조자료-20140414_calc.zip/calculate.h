#ifndef _CALCULATE_H_
#define _CALCULATE_H_

#include "stack.h"

class Calc{

public:
	Calc();
	~Calc();
	int is_operator(int op);
	int precedence(int op);
	int is_legal(char *postfix);
	void infix(char *dst);
	void postfix(char *dst, char *src);
	int eval(char *post);

protected:
	Stack* Storage;

};

Calc::Calc(){
	Storage = new Stack();
}

Calc::~Calc()
{
	delete[] Storage;
}

void Calc::infix(char* dst){

	int i = 0;

	while (1)
	{
		if (dst[i])

		i++;
	}

}


int Calc::is_operator(int op)
{
	return (op == '+' || op == '-' || op == '*' || op == '/' || op == '%' || op == '^');
}

int Calc::precedence(int op)
{
	if (op == '(') return 0;
	if (op == '+' || op == '-') return 1;
	if (op == '%' || op == '*' || op == '/') return 2;
	else return 3;
}

int Calc::is_legal(char *postfix)
{
	int result = 0;
	while (*postfix)
	{
		while (*postfix == ' ')
			postfix++;
		if (is_operator(*postfix))
			result--;
		else
		{
			result++;
			while (*postfix != ' ')
				postfix++;
		}
		if (result < 1) break;
		postfix++;
	}
	return (result == 1);
}



void Calc::postfix(char *dst, char *src)
{
	Storage->init_stack();

	while (*src)
	{
		if (*src == '(')
		{
			Storage->push(*src);
			src++;
		}
		else if (*src == ')')
		{
			while (Storage->get_stack_top() != '(')
			{
				*dst++ = Storage->pop();
				*dst++ = ' ';
			}
			Storage->pop();
			src++;
		}
		else if (is_operator(*src))
		{
			while (!Storage->is_stack_empty() && precedence(Storage->get_stack_top()) >= precedence(*src))
			{
				*dst++ = Storage->pop();
				*dst++ = ' ';
			}
			Storage->push(*src);
			src++;
		}
		else if (*src >= '0' && *src <= '9')
		{
			do
			{
				*dst++ = *src++;
			} while (*src >= '0' && *src <= '9');
			*dst++ = ' ';
		}
		else
			src++;
	}
	while (!Storage->is_stack_empty())
	{
		*dst++ = Storage->pop();
		*dst++ = ' ';
	}
	dst--;
	*dst = 0;
}

int Calc::eval(char *post)
{
	int i;
	Storage->init_stack();
	while (*post)
	{
		if (*post >= '0' && *post <= '9')
		{
			i = 0;
			do
			{
				i = i * 10 + *post - '0';
				post++;
			} while (*post >= '0' && *post <= '9');
			Storage->push(i);
		}
		else if (*post == '+')
		{
			Storage->push(Storage->pop() + Storage->pop());
			post++;
		}
		else if (*post == '*')
		{
			Storage->push(Storage->pop() * Storage->pop());
			post++;
		}
		else if (*post == '-')
		{
			i = Storage->pop();
			Storage->push(Storage->pop() - i);
			post++;
		}
		else if (*post == '/')
		{
			i = Storage->pop();
			Storage->push(Storage->pop() / i);
			post++;
		}
		else if (*post == '%')
		{
			i = Storage->pop();
			Storage->push(Storage->pop() % i);
			post++;
		}
		else if (*post == '^')
		{
			i = Storage->pop();
			Storage->push((int)pow(Storage->pop(), i));
			post++;
		}
		else
			post++;
	}
	return Storage->pop();
}



#endif