#ifndef _ERROR_H_
#define _ERROR_H_

const int FIRST_OP_ERR = 1;
const int DIV_OP_ERR = 2;
const int MOD_OP_ERR = 3;
const int STD_OP_ERR = 4;

class Err{
public:
	Err();
	~Err();
	void MsgBox(int _Type);
	void SetCheck(bool _Check);
	bool GetCheck();
private:
	bool Check;
};

#endif