#ifndef _STACK_H_
#define _STACK_H_

template <class T>
class Stack{
public:
	Stack(){};
	~Stack(){ delete[] Arr; };
	void SetStack(int _Size); // Type�� ���� TYPE_INT, TYPE_CHAR�� ��밡��
	void Push(T _Data);
	T GetData(int IDX);
	int GetTop(){ return Top; }
	T Pop();
protected:
	int Top;
	int Max;
	T *Arr;
};

#include "stack_inc.h"

#endif