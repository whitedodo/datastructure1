#ifndef _STACK_INC_H_
#define _STACK_INC_H_

#include "stack.h"

template <class T>
void Stack<T>::SetStack(int _Size){

	Top = -1;
	Max = _Size + 3;

	Arr = new T[Max];

	for (int i = 0; i <= Max; i++)
		Arr[i] = 0;
}

template <class T>
void Stack<T>::Push(T Data){

	if (Top > Max)
	{
		// �����÷ο� ���
	}
	else
		Arr[++Top] = Data;
}

template <class T>
T Stack<T>::Pop()
{
	if (Top == -1)
	{
		return 0;		// ���� ����÷ο� ���
	}
	else
		return Arr[Top--];
}

template <class T>
T Stack<T>::GetData(int IDX){
	return Arr[IDX];
}

#endif