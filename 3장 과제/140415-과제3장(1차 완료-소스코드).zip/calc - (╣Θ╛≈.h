#ifndef _CALC_H_
#define _CALC_H_

#include <string>
#include "stack.h"

using namespace std;

const int INFIX = 1;
const int POSTFIX = 2;

template <class T>
class Calc{
public:
	Calc(){};
	~Calc(){};

	void SetSize(int _Size){ Size = _Size - 1; };
	void GetPostfix(string _GetData);
	int GetPrevOpCount(string _GetData, int _PrevIDX, int _LastIDX);
	void PrintOut(int Type);
	int Calc<T>::ISP(char _Data);
	int Calc<T>::ICP(char _Data);

	char Calc<T>::StringToChar(int IDX, string _GetData);
	bool Calc<T>::IsOpChk(char _Data);
	
protected: 
	Stack<char>* OpExp;
	Stack<char>* PostExp;

	int Size;
};

template <class T>
void Calc<T>::GetPostfix(string _GetData){

	int IDX;
	int PrevIDX;
	int NextIDX;
	int LastIDX;
	char PrevData;
	char NextData;
	bool Check;

	PostExp = new Stack<char>();
	OpExp = new Stack<char>();

	PostExp->SetStack(Size*2);
	OpExp->SetStack(Size*2);

	IDX = 0;
	PrevIDX = IDX;
	Check = false; // �ʱ� ���ڰ� �ƴҶ� ����

	while (IDX < Size)
	{
		NextData = StringToChar(IDX, _GetData);

		// ������ ��
		if (isdigit(NextData))
		{
			PostExp->Push(NextData);
			Check = true;
		}
		
		// ������ ��
		if (!isdigit(NextData))
		{
			// ���� �տ� ������ ��(-)
			if (Check == false)
				OpExp->Push(NextData);

			// )�� ��
			if (NextData == ')')
			{
				if (PrevIDX == 0)
					LastIDX = -1;
				else
				{
					PrevData = StringToChar(PrevIDX, _GetData);
					if (ISP(PrevData) >= ICP(NextData))
						LastIDX = -1;
					else
						LastIDX = 0;
				}


				while (OpExp->GetTop() > LastIDX)
				{
					PrevData = OpExp->Pop();

					if (ISP(PrevData) >= ICP(NextData))
					{
						PostExp->Push(' ');
						PostExp->Push(PrevData);
					}
				}

				IDX++;
				PrevIDX = IDX;

				OpExp->Push(PrevData);
				OpExp->Push(NextData);
				Check = false; 
				continue;
			}

			// �����ڰ� �°� ó�� ���ڰ� �������� ��
			if (ISP(NextData) != -1 && Check == true)
			{
				NextIDX = IDX; // ���� ������ ����

				PostExp->Push(' ');

				// ���� ���׿����� -�� 1���� ���� ��
				if (GetPrevOpCount(_GetData, PrevIDX, NextIDX) > 1)
				{
					if (PrevIDX == 0)
						LastIDX = -1;
					else
					{
						PrevData = StringToChar(PrevIDX, _GetData);
						if (ISP(PrevData) >= ICP(NextData))
							LastIDX = -1;
						else
							LastIDX = 0;
					}
					
					while (OpExp->GetTop() > LastIDX)
					{
						PrevData = OpExp->Pop();

						if (PrevData == '-')
						{
							PostExp->Push('~');
							PostExp->Push(' ');
						}
						else
							if (PrevData != '(' && PrevData != ')')
							{
								PostExp->Push(PrevData);
								PostExp->Push(' ');
							}
					}

					if (ISP(NextData) >= ICP(PrevData))
						PostExp->Push(NextData);
					else
						OpExp->Push(NextData);

					Check = false;
				}
				else
				{
					if (OpExp->GetTop() != -1)
					{
						if (ISP(OpExp->GetData(OpExp->GetTop()) <= ICP(NextData)))
							LastIDX = -1;
						else
							LastIDX = 0;

						// ������ �ƴ� ��
						if (NextData != '^')
						{
							//PostExp->Push(' ');
							while (OpExp->GetTop() > LastIDX)
							{
								PrevData = OpExp->Pop();
								if (PrevData == '(' || PrevData == ')')
									break;
								else
								{
									PostExp->Push(PrevData);
									PostExp->Push(' ');
								}
								if (PrevData == '^')
									break;
							}
						}

						OpExp->Push(NextData);
					}
					else
						OpExp->Push(NextData);

					Check = false;

				}
				PrevIDX = NextIDX; // ó�� ���� IDX ����
			}

		}

		// (���� �� ������ ������ ���� �ľ��ϱ�
		if ((IDX + 1) == Size && OpExp->GetTop() != -1)
		{
			while (OpExp->GetTop() > -1)
			{
				PrevData = OpExp->Pop();

				if (PrevData != '(' && PrevData != ')')
				{
					PostExp->Push(' ');
					PostExp->Push(PrevData);
				}
			}
		}

		IDX++;
	}

}

template <class T>
int Calc<T>::GetPrevOpCount(string _GetData, int _PrevIDX, int _LastIDX){

	string GetData;
	char TransData;

	int PrevIDX = _PrevIDX;
	int LastIDX = _LastIDX;
	int Count = 0;

	while (PrevIDX < LastIDX)
	{
		GetData = _GetData.substr(PrevIDX, 1);
		TransData = GetData.at(0);
		
		if (TransData == '-')
			Count++;

		PrevIDX++;
	}

	return Count;

}


template <class T>
char Calc<T>::StringToChar(int IDX, string _GetData){

	string GetData = _GetData.substr(IDX, 1);
	return GetData.at(0);
}

template <class T>
int Calc<T>::ISP(char _Data){

	if (_Data == '+' || _Data == '-')
		return 0;
	if (_Data == '%' || _Data == '/' || _Data == '*')
		return 1;
	if (_Data == '^')
		return 2;
	if (isdigit(_Data))
		return 3;
	if (_Data == '(' || _Data == ')')
		return 4;

	return -1;
	
}

template <class T>
int Calc<T>::ICP(char _Data){

	if (_Data == '+' || _Data == '-')
		return 4;
	if (_Data == '%' || _Data == '/' || _Data == '*')
		return 3;
	if (_Data == '^')
		return 2;
	if (isdigit(_Data))
		return 1;
	if (_Data == '(' || _Data == ')')
		return 0;

	return -1;
}

template <class T>
void Calc<T>::PrintOut(int Type){


	for (int i = 0; i <= PostExp->GetTop(); i++)
	{
		switch (Type)
		{
			case POSTFIX:
				cout << PostExp->GetData(i);
				break;

		}
	}
	cout << endl;

}


#endif