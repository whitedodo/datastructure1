#ifndef _CALC_H_
#define _CALC_H_

#include <string>
#include "stack.h"

using namespace std;

const int INFIX = 1;
const int POSTFIX = 2;
const int PARAENTHESE = 3;

template <class T>
class Calc{
public:
	Calc(){};
	~Calc(){};

	void SetSize(int _Size){ Size = _Size - 1; };
	void GetPostfix(string _GetData);
	int GetPrevOpCount(string _GetData, int _PrevIDX, int _LastIDX);
	void PrintOut(int Type);
	int ISP(char _Data);
	int ICP(char _Data);

	char StringToChar(int IDX, string _GetData);
	bool IsOpChk(char _Data);
	bool IsPrevParaenthese(string _GetData, int _PrevIDX, int LastIDX);
	
protected: 
	Stack<char>* OpExp;
	Stack<char>* PostExp;

	int Size;
};

template <class T>
void Calc<T>::GetPostfix(string _GetData){

	int IDX;
	int PrevIDX;
	int NextIDX;
	int LastIDX;
	char TmpData;
	char PrevData;
	char NextData;
	bool Check;

	PostExp = new Stack<char>();
	OpExp = new Stack<char>();
	Stack<char>* TmpExp = new Stack<char>();

	PostExp->SetStack(Size * 2);
	OpExp->SetStack(Size * 2);
	TmpExp->SetStack(Size * 2);

	IDX = 0;
	PrevIDX = IDX;
	Check = false; // �ʱ� ���ڰ� �ƴҶ� ����

	while (IDX <= Size)
	{
		NextData = StringToChar(IDX, _GetData);

		// ������ ��
		if (isdigit(NextData))
		{
			PostExp->Push(NextData);
			Check = true;
		}
		
		// ������ ��
		if (!isdigit(NextData))
		{
			// ���� �տ� ������ ��
			if (Check == false)
			{
				OpExp->Push(NextData);

				if(NextData == '(')
					PrevIDX = IDX;

				IDX++;
				continue;
			}

			// ')��ȣ�� ��')
			if (NextData == ')')
			{

				while (OpExp->GetTop() > -1)
				{
					PrevData = OpExp->GetData(OpExp->GetTop());
					
					if (PrevData == '(')
					{
						NextData = OpExp->Pop();
						PrevData = OpExp->GetData(OpExp->GetTop());

						if (PrevData == '(' && NextData == '(')
							break;
						else
						{
							continue;
						}
					}

					// ���� (��ȣ�� ��, ������ (��ȣ�� ��
					if (PrevData == '(' && NextData == '(')
					{
						break;
					}

					// ISP(NextData) <= ICP(PrevData)
					if (ISP(NextData) <= ICP(PrevData))
					{
						if (NextData == '(' || PrevData == '(')
						{
							if (NextData == PrevData)
							{
								NextData = OpExp->Pop();
								PostExp->Push(NextData);
							}
							else{

								// �Է� ������ �´��� Ȯ��
								if (NextData != '(' && PrevData != '^')
									break;
								else
								{
									// ^�� ��
									TmpData = PostExp->GetData(PostExp->GetTop());
									
									if (TmpData == '^'){
										NextData = OpExp->Pop();
										PostExp->Push(NextData);
									}
									else
										break;

								}
							}
						}
						else{
							NextData = OpExp->Pop();
							PostExp->Push(NextData);
						}
					}
					else
					{
						PrevData = OpExp->Pop();
						PostExp->Push(PrevData);

						if (PrevData == '(' && NextData == '(')
							break;
						else
						{
							continue;
						}
					}
				}

				// ������ �� ��
				if (IDX == Size)
				{
					while (OpExp->GetTop() > -1)
					{
						PrevData = OpExp->Pop();
						if (ISP(PrevData) == PARAENTHESE)
							continue;

						PostExp->Push(PrevData);

					}
					break;
				}


				PrevIDX = IDX;
				IDX++;
				Check = false;
				continue;
			}

			if (Check == true){
				LastIDX = IDX;

				// �� ó�� ���� �չ��ڰ� -������ ��
				if (GetPrevOpCount(_GetData, PrevIDX, LastIDX) > 0 && PrevIDX == 0)
				{
					while (OpExp->GetTop() != -1)
					{
						PrevData = OpExp->Pop();
						if (PrevData == '-')
							PostExp->Push('~');
					}

					OpExp->Push(NextData);

					PrevIDX = IDX;
					IDX++;
					Check = false;
					continue;
				}

				// �� ó�� ���� �չ��ڰ� -������ �ƴ� ��
				if (GetPrevOpCount(_GetData, PrevIDX, LastIDX) == 0 && PrevIDX == 0)
				{
					OpExp->Push(NextData);

					PrevIDX = IDX;
					IDX++;
					Check = false;
					continue;
				}

				// ISP(NextData) < ICP(PrevData)�� ���� ��
				PrevData = StringToChar(PrevIDX, _GetData);

				if (ISP(NextData) < ICP(PrevData))
				{

					// PrevIDX(���� �������� ���� �������� -�������� 2�̻��� ��
					if (GetPrevOpCount(_GetData, PrevIDX, IDX)  > 1)
					{
						while (OpExp->GetTop() > 0)
						{
							PrevData = OpExp->GetData(OpExp->GetTop());
							if (PrevData == '-'){
								PrevData = OpExp->Pop();
								PostExp->Push('~');
							}
						}

						PrevIDX = IDX;
						OpExp->Push(NextData);
						Check = false;
						IDX++;
						continue;
					}
					else
					{
						// �¼��� �ƴ� ��
						if (NextData != '^')
						{
							while (OpExp->GetTop() > -1)
							{
								PrevData = OpExp->GetData(OpExp->GetTop());
								if (PrevData == '(')
									break;
								else
								{
									PrevData = OpExp->Pop();
									PostExp->Push(PrevData);

									PrevData = StringToChar(PrevIDX, _GetData);
									if (PrevData == '^')
										break; 

								}
							}

							PrevIDX = IDX;
							OpExp->Push(NextData);
							Check = false;
							IDX++;
							continue;
						}
						// ^�� ��
						else
						{
							OpExp->Push(NextData);
							
							Check = false; 
							PrevIDX = IDX;
							IDX++;
							continue;
						}

					}


				}
				// ISP(NextData) >= ICP(PrevData)
				else
				{

					while (OpExp->GetTop() > -1)
					{
						PrevData = OpExp->GetData(OpExp->GetTop());
						
						// ������ ���� ���� ��
						if (ISP(PrevData) < ICP(NextData))
							break;
						else
						{
							// �������� ��
							if (NextData == '^')
								break;

							// ��ȣ�� ��
							if (PrevData == '(')
								break;

							PrevData = OpExp->Pop();
							// ��ȣ ����
							if (ISP(PrevData) == PARAENTHESE)
								continue;

							PostExp->Push(PrevData);
						}

					}
					
					PrevIDX = IDX;
					OpExp->Push(NextData);
					Check = false;
					IDX++;
					continue;
				}

			}
			else
			{

				PrevData = OpExp->Pop();
				PostExp->Push(PrevData);
				PrevIDX = IDX;
				OpExp->Push(NextData);
				Check = false;
				IDX++;
			}
		}

		// ������ �� ��
		if (IDX == Size)
		{
			while (OpExp->GetTop() > -1)
			{
				PrevData = OpExp->Pop();
				if (ISP(PrevData) == PARAENTHESE)
					continue;

				PostExp->Push(PrevData);

			}
		}

		IDX++;
	}

}

template <class T>
int Calc<T>::GetPrevOpCount(string _GetData, int _PrevIDX, int _LastIDX){

	string GetData;
	char TransData;

	int PrevIDX = _PrevIDX;
	int LastIDX = _LastIDX;
	int Count = 0;

	while (PrevIDX < LastIDX)
	{
		GetData = _GetData.substr(PrevIDX, 1);
		TransData = GetData.at(0);
		
		if (TransData == '-')
			Count++;

		PrevIDX++;
	}

	return Count;

}

template <class T>
bool Calc<T>::IsPrevParaenthese(string _GetData, int _PrevIDX, int LastIDX){

	int IDX = _PrevIDX;
	int Cnt = 0;
	char Data;

	while (IDX < LastIDX)
	{
		Data = StringToChar(IDX, _GetData);

		if (Data == '(')
			Cnt++;

		IDX++;
	}

	if (Cnt > 0)
		return true;
	else
		return false;
}

template <class T>
char Calc<T>::StringToChar(int IDX, string _GetData){

	string GetData = _GetData.substr(IDX, 1);
	return GetData.at(0);
}

template <class T>
int Calc<T>::ISP(char _Data){

	if (_Data == '+' || _Data == '-')
		return 0;
	if (_Data == '%' || _Data == '/' || _Data == '*')
		return 1;
	if (isdigit(_Data) || _Data == '^')
		return 2;
	if (_Data == '(' || _Data == ')')
		return 3;

	return -1;
	
}

template <class T>
int Calc<T>::ICP(char _Data){

	if (_Data == '+' || _Data == '-')
		return 3;
	if (_Data == '%' || _Data == '/' || _Data == '*')
		return 2;
	if (isdigit(_Data) || _Data == '^')
		return 1;
	if (_Data == '(' || _Data == ')')
		return 0;

	return -1;
}

template <class T>
void Calc<T>::PrintOut(int Type){

	cout << "���:";

	for (int i = 0; i <= PostExp->GetTop(); i++)
	{
		switch (Type)
		{
			case POSTFIX:
				cout << PostExp->GetData(i);
				break;

		}
	}
	cout << endl;

}


#endif