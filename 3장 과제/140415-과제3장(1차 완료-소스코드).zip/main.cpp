#include <iostream>
#include <string>
#include "calc.h"

using namespace std;

int main()
{
	Calc<int>*CalApp = new Calc<int>();
	string GetUserData;

	while (1)
	{
		cin >> GetUserData;
		int Size = (int)GetUserData.length();

		if (Size != 0)
		{
			CalApp->SetSize(Size);
			CalApp->GetPostfix(GetUserData);
			CalApp->PrintOut(POSTFIX);
		}

	}
	

}