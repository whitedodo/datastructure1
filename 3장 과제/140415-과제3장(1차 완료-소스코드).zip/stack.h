#ifndef _STACK_H_
#define _STACK_H_

template <class T>
class Stack{
public:
	Stack(){};
	~Stack(){};
	void SetStack(int _Size);
	void Push(T _Data);
	T GetData(int IDX);
	int GetTop(){ return Top; }
	T Pop();
protected:
	int Top;
	int Max;
	T *Arr;
};

template <class T>
void Stack<T>::SetStack(int _Size){

	Top = -1;
	Max = _Size;
	Arr = new T(Max);
}

template <class T>
void Stack<T>::Push(T Data){

	if (Top > Max)
	{
		// �����÷ο� ���
	}
	else
		Arr[++Top] = Data;
}

template <class T>
T Stack<T>::Pop()
{
	if (Top == -1)
	{
		return 0;		// ���� ����÷ο� ���
	}
	else
		return Arr[Top--];
}

template <class T>
T Stack<T>::GetData(int IDX){
	return Arr[IDX];
}
#endif